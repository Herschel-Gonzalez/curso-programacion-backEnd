<?php
//retornara un select con las marcas, que leera desde un archivo
    function cargarMarcas(){
        $fh = fopen("marcas.txt",'r') or die ("Error al crear el archivo");
        $opt = "";
        while ($l = fgets($fh)) {
           // $opt.="<option value='".trim($l)."'>$l</option>";
            $opt.='<option value="'.trim($l).'">'.$l.'</option>';
        }
        fclose($fh);

        return $opt;

    }

    function seleccionar_marca($marca){
        $fh = fopen("marcas.txt",'r') or die ("Error al crear el archivo");
        $opt = "";
        $s = "";
        while ($l = fgets($fh)) {
           if ($marca==trim($l)) {
            $s="selected";

           }else{
            $s="";
           }
           $opt.="<option value='".trim($l)."'$s>$l</option>";
        }
        fclose($fh);
        return $opt;

    }
    

?>