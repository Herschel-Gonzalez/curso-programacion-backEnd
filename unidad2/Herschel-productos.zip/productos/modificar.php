<?php

    $codigo = strval($_POST['codigo']);
    $nombre = strval($_POST['nombre']);
    $marca = intval($_POST['marca']);
    $existencias = intval($_POST['existencias']);
    $stock_minimo = intval($_POST['stockMinimo']);
    $stock_maximo = intval($_POST['stockMinimo']);
    $costo = intval($_POST['costo']);
    


?>